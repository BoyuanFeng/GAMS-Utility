This folder contains all files associated with the longest connected component utility. Any inquries relating to bugs or 
compatibility issues should be directed to the following email address:

ngale3737@gmail.com

All contents of this folder were written by:
Nathaniel Gale